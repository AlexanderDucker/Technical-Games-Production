using System;

namespace MonochromeRainbow
{
	public class UISceneManager
	{
		public UISceneManager ()
		{
		}
	}
}

