using System;
using System.Threading;

using Sce.PlayStation.Core;
using Sce.PlayStation.Core.Graphics;
using Sce.PlayStation.Core.Input;
using Sce.PlayStation.Core.Environment;

using Sce.PlayStation.HighLevel.GameEngine2D;
using Sce.PlayStation.HighLevel.GameEngine2D.Base;
using Sce.PlayStation.HighLevel.UI;

/*namespace MonochromeRainbow
{
	public class Menu
	{
		private	TextureInfo	textureInfo;
		private SpriteUV sprite;
		public Button startButton;
		
		public Menu (Sce.PlayStation.HighLevel.GameEngine2D.Scene scene, int level)
		{
			textureInfo = new TextureInfo("Application/textures/MenuScreen.png");
			sprite = new SpriteUV(textureInfo);
			sprite.Quad.S = textureInfo.TextureSizef;
			scene.AddChild (sprite);
			Label label = new Label();
			label.SetPosition(0.0f, 0.0f);
			label.text = "woop".
			customButton.Text = "Start";
			
			LoadMenus (level, scene);
		}
		
		public void LoadMenus(Sce.PlayStation.HighLevel.GameEngine2D.Scene scene, int level)
		{
			if(level == 0)
			{
				newGame = new Button(scene, "/Application/textures/Buttons/NewGame.png", new Vector2(380, 242));
			}
		}
		
		public void Update(int level)
		{
		}
	}
}*/

